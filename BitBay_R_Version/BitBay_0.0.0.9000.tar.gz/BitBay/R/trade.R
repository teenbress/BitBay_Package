##' Trading Strategy (Description)
##'
##' Predict possible selling and buying time points and their correspoinding prices.
##' @title trade evaluation;
##' @param prices the prices dataset for predicting the prices of bitcoin.nrow(x) should be larger than 180,containing more than 720 elements.
##' @param dp the price change calculated by Bayesian;
##' @return  selling and buying time points and their correspoinding prices;the overall evaluation;
##' @author Qiao Yu
##' @export
##'

trade <- function(prices,dp){
  bb_point<-data.frame()
  ss_point<-data.frame()
  tfee_buy <- 0.001
  tfee_sell <- 0.003
  fee=0
  position=0
  profit=0
  temp=0
  counts=0
  counttotal=0
  n=length(prices)
  error<-NULL
  t <-730:(n-1)
  k=length(t)
  s_point<-data.frame()
  for (j in 1:k){
    error[j] =  abs(prices[j+720]-prices[j+719]-dp[j])
    #Buy
    if ((dp[j]*100 > tfee_buy) & (position == 0)){
      position <- 1
      temp <- prices[j+719]
      print(j)
      bb_point = rbind( bb_point,c(j+179))
      cat("Buying at ", temp, "\n")
      
    }
   
    #Sell;
    if((dp[j]*100 < -tfee_sell) &  (position == 1)){
      position <- 0
      profit = profit + prices[j+719]-temp
      print(j)
      cat("Selling at ", prices[j+179], "\n")
      ss_point = rbind(ss_point,c(j+179))
      counttotal <- counttotal+1
      if (prices[j+179]-temp>0){
        counts <- counts+1
      }
    }
     proba = (counts/counttotal)*100
  }
  print("Selling point")
  print(ss_point)
  print("Buying points")
  print(bb_point)
  s_point<-t(ss_point)
  b_point<-t(bb_point)
  cat("Error of prediction on average : ", sum(error)/n,"\n")
  cat("Win rate: ", proba,"\n") 
  cat("Total profit: ", profit,"\n")
  write.csv( s_point,"s_point.csv")
  write.csv( b_point, "b_point.csv")
}
 




