
##' Bayesian Price change (Description)
##'
##' Calculate the  data variation through empirical data by Bayesian regression model.
##' @title Bayesian
##' @param x The dataset need to be analysed and predicted;
##' @param S The emperical dataset used to predict the first dataset,the nrow of S should larger than 20,the ncol of S should be less than the length of x;
##' @return average price change dp;
##' @author Qiao Yu
##' @export
##' @examples
##' set.seed(12344)
##' a<-rnorm(10,10,2)
##' S<-matrix(rnorm(400,10,4),20,20)
##' bayesian(a,S)

bayesian <- function(x,S){
  c = -1/4
  distance<-NULL
  price<-NULL
  dp<-NULL
  cutS=S[1:20,1:length(x)]
  for(i in 1:20){
    distance[i]=exp(c*norm(x-cutS[i,], type="2")^2)
    price[i]=S[i,(length(x)+1)]* distance[i]
  }
  stopifnot(!distance==0)
  dp = sum(price)/sum(distance)
  return(dp)
}



