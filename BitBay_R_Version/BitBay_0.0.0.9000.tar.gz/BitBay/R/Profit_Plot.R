##'Plot the key time points (Description)
##'
##' We want to Visualization of the results of trading strategy. Plot the prices of bitcoin and mark the buying and selling points to check the consistency of the trading strategy.
##' @title Profit_plot
##' @param prices the price dataset used for predicting the trend of the prices.
##' @param bpoint buying point index marked with red color;
##' @param spoint selling point index marked with green color;
##' @author Qiao Yu
##' @export


profit_plot<-function(prices,bpoint,spoint){
  
  n<-length(prices)
  
  fbuy <- prices[bpoint]
  
  fsell <- prices[spoint]
  
  par(bg="white")
  
  plot(1:n,prices,type="l",col="lightskyblue",main = "Prediction for Bitcoins")
  
  points(bpoint,fbuy,col="red",pch=20,cex=2)
  
  points(spoint,fsell,col="limegreen",pch=20,cex=2)
  
  legend("topright", lty=c("solid","dashed"),col = c("limegreen","red"),legend = c("Selling points","Buying points"))
}
