##' Sample Entropy (Description)
##'
##' Calculate the entropy of clustered sample data after k-means clustering; 
##' Measures the complexity of a time series. Large values of the Sample Entropy indicate high complexity whereas that smaller values characterize more regular signals;
##' @title SampEntropy
##' @param data A sampleEntropy object, should be a matrix or a vector;
##' @param r the radius of the neighbourhood, Set as the threshhold for comparing the similarity of the sample matrix;r could be changed to other parameters such as the sd of xdata;
##' @return the sample entropy.
##' @author Qiao Yu
##' @export
##' @examples
##' 
##' a<-matrix(rnorm(60,3,0.4),15,4)
##'
##' SampEntropy(a)

SampEntropy <- function(data){
  data<-as.matrix(data)
  n <- ncol(data) #If the type of data  is vector,then n would be null, then change the code into "n <- ncol(data)";
  cr<-NULL
  sum1<-NULL
  m<-NULL
  for(i in 1:2)
  {
    r<-0.2
    m[i]=i+1
    n <- length(data)
    sam<-sapply(1:m[i],function(x)(data[x:(n-m[i]+x)]))
    maxRdiff<-function(x)apply(abs(sweep(sam[-x,],2,sam[x,],"-")),1,max)
    d<-t(sapply(1:(n-m[i]+1),maxRdiff))
    cr1<-sapply(1:nrow(d),function(x)length(which(d[x,]<r)))
    sum1[i]<-sum(cr1/(n-m[i]))/(n-m[i]+1)
    cr[i]=sum1[i]
  }
  cr
  sampEntropy <- log(cr[1])-log(cr[2])
  return(sampEntropy)
}
